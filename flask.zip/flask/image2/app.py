import requests
from flask import Flask, jsonify, request
import json




app = Flask(__name__)
  
@app.route("/api/", methods=["POST"])
def hello():
	#a = request.json.get("a")
	#b = request.json.get("b")
	#return jsonify({a:b})
	data = request.get_json()
	print(data)
	return jsonify(data)
	
if __name__ == '__main__':
   app.run(debug=True, port=5052, host='0.0.0.0')
